/*
Editors: Malachi Parks, Kelsey McRae
Assignment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include "mp3.h"
#define	BUFFERSIZE 128

extern mp3_t *head;

int deleteItems(char *);// function declaration

int deleteItems(char * nameBuffer){
	//Variable declarations
	mp3_t *current;		//Creating mp3 pointer to use on head

	// Prompting user for artist name to delete from
		if(head == NULL){	//if list is empty
			printf("The list is empty\n");
			return 0;
		}//if
		else{ //non-empty list
			current = head;
			while(current!=NULL){
				if(strcmp(current->artist,nameBuffer)==0){// if the current node has the artist value that needs to be removed
					if(current==head){//current node is the head node
						head=current->next;
						//freeing information from structs
						free(current->artist);
						free(current->title);
						free(current);
						return 1; //return 1 to continue loop
					}//if
					else{//not head node
						if(current->prev != NULL && current->next != NULL){ // node is in the middle
							current->prev->next=current->next; // make previous node point to currents next
							current->next->prev=current->prev;// making next node prev point to currents prev
							//freeing information from structs
							free(current->artist);
							free(current->title);
							free(current);
							return 1; // return 1 to coninue loop
						}//if
						else{
							current->prev->next = NULL; // setting node before it's next to NULL
							//freeing information from struct
							free(current->artist);
							free(current->title);
							free(current);
							return 0;
						}//else
					}//else
				}//if
				else{//traverse list until finds node with data
					current=current->next;
				}//else
			}//while
		}//else
}//deleteItemsv2.c
