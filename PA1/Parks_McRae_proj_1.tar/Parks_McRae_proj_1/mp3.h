/*
Editors: Malachi Parks, Kelsey McRae
Assignment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
 
/*
typedef struct node
{
  char *name;    
  int   data;
  struct node *next;
} node_t; 
*/

// struct for mp3  node
typedef struct mp3{
	char* artist;//artist who produced the song
	char* title;// name of the song
	int runTime;//How long the song plays for
	struct mp3 *next; //next song in the playlist
	struct mp3 *prev; //prev song in the playlist
} mp3_t;
