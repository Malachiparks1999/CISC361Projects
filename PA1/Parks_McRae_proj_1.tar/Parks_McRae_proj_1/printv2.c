/*
Editors: Malachi Parks, Kelsey McRae
Assignment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include "mp3.h"

extern mp3_t *head;
mp3_t *tail;

void print()
{
  mp3_t *temp;
  int  i = 0;
  char order;

  temp = head;
  printf("Would you like to print the list from beginning to end(b) or end to beginning(e)? (Enter 'b' or 'e')");
  scanf("%c",&order);

  switch(order){
	case 'b':
		temp = head; 
 		if (temp == NULL) {
			printf("List is empty");
  		} else {
	 		while (temp != NULL) {
    				printf("(%d)\tArtist:%s\tSong Title:%s\tSong duration in minutes:%d\n", ++i, temp->artist, temp->title, temp->runTime);
    				temp = temp->next;
			}
		}
		break;
	case 'e':
		tail = head; // setting tail to head
		while(tail->next != NULL){//iterating through to make tail pointer to last node
			tail = tail->next;
		}//while		
		while(tail != NULL){
			printf("(%d)\tArtist:%s\tSong Title:%s\tSong duration in minutes:%d\n",++i, tail->artist, tail->title, tail->runTime);
			tail=tail->prev;//making it move backwards
		}//while
		break;
	default:
		printf("Entered character not valid");

  }
}
