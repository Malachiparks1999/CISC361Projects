/*
Editors: Malachi Parks, Kelsey McRae
Assignment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include "mp3.h"

extern mp3_t *head;

void freeList()
{
  mp3_t *temp;
  int  i = 0;

  while (head != NULL) {
    temp = head;
    head = head->next; // point to next MP3 record
    free(temp->artist);  // first free artist name inside MP3 record
    free(temp->title);  // second free the title of the song inside MP3 record
    free(temp);        // then free MP3 record
    i++;
  }
  printf("free %d MP3 records...\n", i);
}
