/*
Editors: Malachi Parks, Kelsey McRae
Assignment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include "mp3.h"

extern mp3_t *head;

void insert(char *artistName, char* songTitle, int duration); // function definition for insert function

void insert(char *artistName, char* songTitle, int duration){
	mp3_t *temp, *mp3; // making two new node pointers

	// Mallocing space for mp3 struct
	mp3 = (mp3_t *) malloc(sizeof(mp3_t));		// malloc space for mp3
	mp3->artist = (char *) malloc(strlen(artistName) + 1);		// malloc space for song creator
	mp3->title = (char *) malloc(strlen(songTitle) + 1);		// malloc space for song name

	//  Binding variables to values inside mp3
	strcpy(mp3->artist, artistName);	//"assign" name via copy
	strcpy(mp3->title, songTitle);		//"assigh" title via copy
	mp3->runTime =  duration;		// assign time value
	mp3->next = NULL;			// assigning pointers to null, will assign within loop
	mp3->prev = NULL;

	if(head == NULL){// if list is empty i.e first element
		head = mp3;
	}//if
	else{//list is not empty
		temp = head;
		while(temp->next != NULL){ // iterating through Linked List
			temp= temp->next;
		}//while
		temp->next = mp3;	//Adding element to end of list
		mp3->prev = temp;	// linking with last element in list
	}//else
}//insert
