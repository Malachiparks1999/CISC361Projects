//
// adapted from http://www.cprogramming.com/snippets/source-code/singly-linked-list-insert-remove-add-count
//

/*
Editors: Malachi Parks, Kelsey, McRae
Assighment: Programming Assignment 1
Section: CISC361-010
Due Date: 9/14/2020
*/

#include "mp3.h"
#define  BUFFERSIZE 128

mp3_t *head;

void insert(char *name, char *title,int length);
void print();
void freeList();
int deleteItems(char *);

int main()
{
  int i, num, len;
  struct mp3_t *n;
  char buffer[BUFFERSIZE],titleBuffer[BUFFERSIZE], nameBuffer[BUFFERSIZE],c;

  head = NULL;

  while (1) {
    printf("\nList Operations\n");
    printf("===============\n");
    printf("(1) Insert\n");
    printf("(2) Display\n");
    printf("(3) Delete\n");
    printf("(4) Exit\n");
    printf("Enter your choice : ");
    if (scanf("%d%c", &i, &c) <= 0) {          // use c to capture \n
        printf("Enter only an integer...\n");
        exit(0);
    } else {
        switch(i)
        {
        case 1: printf("Enter the artist's name : ");
		if(fgets(buffer, BUFFERSIZE , stdin) != NULL) {
                  len = strlen(buffer);
                  buffer[len - 1] = '\0';   // override \n to become \0
                }//if 
		else {
                    printf("wrong name...");
                    exit(-1);
                }//else
		//taking in information on the song's title
		printf("Enter the song title : ");
		if(fgets(titleBuffer,BUFFERSIZE,stdin) != NULL){
			len = strlen(titleBuffer);
			titleBuffer[len - 1] = '\0';	// override \n to become \0
		}//if
		else{
			printf("Incorrect title...");
			exit(-1);
		}//else
                printf("Enter the song's runtime as an integer: ");
                scanf("%d%c", &num, &c);  // use c to capture \n
                printf("Artist: %s  Title: %s  Runtime: %d\n", buffer,titleBuffer, num);
                insert(buffer,titleBuffer, num);
                break;
        case 2: if (head == NULL)
                  printf("List is Empty\n");
                else
                  print();
                break;
        case 3:
		printf("Enter the name of an artist you want to remove from the list: ");
		if(fgets(nameBuffer,BUFFERSIZE, stdin) != NULL){//input is not empty
			int buffLen = 0;	// holds how long the buffer is
			buffLen = strlen(nameBuffer);
			nameBuffer[buffLen-1]='\0'; // forcing null character to terminate
		}//if
		while(deleteItems(nameBuffer) != 0){
			printf("Deleteing In Progress...\n");
		}//while
		printf("Deletion Completed\n");
                break;
        case 4: freeList();
                return 0;
        default: printf("Invalid option\n");
        }
    }
  }
  return 0;
}
