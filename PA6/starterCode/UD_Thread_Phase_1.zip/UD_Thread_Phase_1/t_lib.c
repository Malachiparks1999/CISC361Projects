#include "t_lib.h"

tcb *running;
tcb *ready;

void t_yield()
{
  tcb* tmp;
  tmp = running; // store the currently running thread in tmp
  tmp->next = NULL;
  
  if (ready != NULL) { // only yield if there is a TCB in ready queue
    running = ready; // first TCB in ready queue becomes running 
    ready = ready->next; // ready to next thread
    running->next = NULL;
    tcb* iter;
    iter = ready;
    if (iter == NULL) // if there is nothing else in ready queue
      ready = tmp;
    else { 
      while (iter->next != NULL) // loop till end of queue
        iter = iter->next;
      iter->next = tmp; //add tmp to end of queue
    }
	
    swapcontext(tmp->thread_context, running->thread_context);
  }
}

/* Initialize the UD thread library by setting up the "running" 
and the "ready" queues, creating the TCB of the "main" thread,
and inserting it into the running queue. */
void t_init()
{
  tcb *tmp = (tcb *) malloc(sizeof(tcb));
  tmp->thread_context = (ucontext_t *) malloc(sizeof(ucontext_t));
  getcontext(tmp->thread_context);
  tmp->next = NULL;
  tmp->thread_id = 0;  // main thread has ID 0 running = tmp;
  running = tmp;
  ready = NULL; 
}

/* Create a thread with priority pri, start function func with argument 
thr_id as the thread id. Function func should be of type void func(int).
TCB of the newly created thread is added to the end of the "ready" queue;
the parent thread calling t_create() continues its execution upon returning
from t_create(). */

int t_create(void (*fct)(int), int id, int pri)
{ 
  size_t sz = 0x10000;
  tcb* tmp = (tcb*) malloc(sizeof(tcb));
  tmp->thread_context = (ucontext_t *) malloc(sizeof(ucontext_t));

  getcontext(tmp->thread_context);
  tmp->thread_context->uc_stack.ss_sp = malloc(sz);  /* new stack */
  tmp->thread_context->uc_stack.ss_size = sz;
  tmp->thread_context->uc_stack.ss_flags = 0;
  tmp->thread_context->uc_link = running->thread_context;
  makecontext(tmp->thread_context, (void (*)(void)) fct, 1, id);
  tmp->thread_id = id;
  tmp->thread_priority = pri;
  tmp->next = NULL;

  if (ready == NULL)
    ready = tmp;
  else {
    tcb* t = ready;
    while(t->next != NULL) {
      t = t->next;
    }
    t->next = tmp; // insert to the end of ready queue
  }
}

/* Terminate the calling thread by removing (and freeing) its TCB from the
"running" queue, and resuming execution of the thread in the head of the 
"ready" queue via setcontext(). */
void t_terminate()
{
  tcb* tmp;
  tmp = running;
  running = ready;  // 1st ready TCB becomes running

  if (ready != NULL)
    ready = ready->next;  // every TCB in ready moves forward

  free(tmp->thread_context->uc_stack.ss_sp);
  free(tmp->thread_context);
  free(tmp);

  setcontext(running->thread_context);  // resume running TCB
}

// free all the TCBs to avoid memory leaks
void t_shutdown()
{
  if (ready != NULL) {
    tcb* tmp;
    tmp = ready;
    while (tmp != NULL) {
      ready = ready->next;
      free(tmp->thread_context->uc_stack.ss_sp);
      free(tmp->thread_context);
      free(tmp);
      tmp = ready;
    }
  }

  free(running->thread_context);
  free(running);	
}
